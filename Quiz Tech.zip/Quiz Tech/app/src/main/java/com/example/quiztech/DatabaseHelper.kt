package com.example.quiztech

import android.app.Activity
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

var ver = 2

class DatabaseHelper(var ctx:Activity):SQLiteOpenHelper(ctx,"QuizTechDB",null,ver) {
    override fun onCreate(db: SQLiteDatabase?) {
        var tblque  = "CREATE TABLE questions(id INTEGER PRIMARY KEY AUTOINCREMENT,que TEXT,a TEXT,b TEXT,c TEXT,d TEXT,ans TEXT)"
        db?.execSQL(tblque)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS questions")
    }
    fun addQue(arQue:ArrayList<String>) : Long
    {
        var i = 0
        var res:Long = 0
        var db = writableDatabase
        var cv = ContentValues()
        while(i < arQue.size) {
            cv.put("que",arQue[i])
            cv.put("a",arQue[i+1])
            cv.put("b",arQue[i+2])
            cv.put("c",arQue[i+3])
            cv.put("d",arQue[i+4])
            cv.put("ans",arQue[i+5])
            res = db.insert("questions",null,cv)
            i += 6
        }
        return res
    }
    fun delQue() : Int
    {
        var db = writableDatabase
        var res= db.delete("questions",null,null)
        return res
    }
    fun fetchQue() : ArrayList<String>
    {
        var arQue = ArrayList<String>()
        var db = readableDatabase
        var cr = db.rawQuery("SELECT * FROM questions",null)
        if(cr.moveToFirst()) {
            do {
                arQue.add(cr.getString(1))
            }while (cr.moveToNext())
        }
        cr.close()
        db.close()
        return arQue
    }
    fun fetchOption(q:String) : ArrayList<String>
    {
        var arQue = ArrayList<String>()
        var db = readableDatabase
        var cr = db.rawQuery("SELECT * FROM questions WHERE que = '"+ q +"'",null)
        if(cr.moveToFirst()) {
            do {
                arQue.add(cr.getString(2))
                arQue.add(cr.getString(3))
                arQue.add(cr.getString(4))
                arQue.add(cr.getString(5))
            }while (cr.moveToNext())
        }
        cr.close()
        db.close()
        return arQue
    }
    fun fetchAns(q:String) : String
    {
        var ans = ""
        var db = readableDatabase
        var cr = db.rawQuery("SELECT * FROM questions WHERE que = '"+ q +"'",null)
        if(cr.moveToFirst()) {
            do {
                ans = cr.getString(6)
            }while (cr.moveToNext())
        }
        cr.close()
        db.close()
        return ans
    }
    fun viewAll() : ArrayList<String>
    {
        var i:Int = 1
        var arQue = ArrayList<String>()
        var db = readableDatabase
        var cr = db.rawQuery("SELECT * FROM questions",null)
        if(cr.moveToFirst())
        {
            do
            {
                var sc = cr.getInt(3)
                arQue.add("No. "+  i.toString())
                arQue.add("Que: "+ cr.getString(0))
                arQue.add("A: "+ cr.getString(1))
                arQue.add("B: "+ cr.getString(2))
                arQue.add("C: "+ cr.getString(3))
                arQue.add("D: "+ cr.getString(4))
                arQue.add("Ans: "+ cr.getString(5))
                arQue.add(" ")
                i += 1
            }while (cr.moveToNext())
        }
        cr.close()
        db.close()
        return arQue
    }
}