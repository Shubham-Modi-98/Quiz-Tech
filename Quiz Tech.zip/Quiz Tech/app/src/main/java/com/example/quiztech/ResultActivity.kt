package com.example.quiztech

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_result.*

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        var score = intent.getIntExtra("score",0)
        var no = intent.getIntExtra("no",0)
        Correct.text = "Correct Answer is : $score out of $no"
        QuizScore.text = "Quiz Score : $score"
        HomeButton.setOnClickListener {
            var intent1 = Intent(this,HomeActivity::class.java)
            startActivity(intent1)
            finish()
        }
    }
}
