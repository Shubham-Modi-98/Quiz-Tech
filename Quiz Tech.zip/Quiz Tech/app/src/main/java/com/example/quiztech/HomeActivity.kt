package com.example.quiztech

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_home.*

var arQueNo = ArrayList<Int>()
var pos:Int = 0
var arQue = ArrayList<String>()
var res:Long = 0

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        arQue = arrayListOf("Which of the following is true about C","Machine Independent","High Level Language","Low Level Language","User Independent","Machine Independent"
            ,"Which of the following is not true about C","C provide function oriented programming","C programs can be compiled on a C++ compiler"
            ,"C supports encapsulation false","none of these","C supports encapsulation false"
            ,"Who is the founder of C language","Ken Thompson","Brian Kernighan","Dennis Ritchie","Rob Pike","Dennis Ritchie"
            ,"`Stderr` is a standard error","Standard error library","Standard error streams","Standard error types","Standard error function"
            ,"Standard error streams"
            ,"What actually get pass when you pass an array as a function argument","First value of element in array","All value of element in array"
            ,"Base address of array","Address of the last element of array","Base address of array"
            ,"Which printf() statement will you used to print Float a = 3.14 and Double b = 3.14","printf('%f%f',a,b);","printf('%f%lf',a,b);"
            ,"printf('%lf%lf',a,b);","printf('%lf%f',a,b);","printf('%f%lf',a,b);"
            ,"In the given statement, what does the `pf` indicate int(*pf)();","pf is a pointer of a function which return int","pf is a pointer"
            ,"pf is a function pointer","none of the above","pf is a pointer of a function which return int"
            ,"What is the full form of `stdio` header file","Stand for input output","Standard input output","System input output"
            ,"input output standard","Standard input output"
            ,"Which of the following are NOT relational operators","<",">","==","<=","=="
            ,"Which symbol is used to make comments in C","//","#","!!","<!-","//"
            ,"In a C program, the first statement that will be executed is","The first executable statement of the program","The first executable statement of the main() function"
            ,"The first executable statement of the first line","The first executable statement of the end function","The first executable statement of the main() function"
            ,"How would you insert pre-written code into a current program","#read","#get","#include","#pre","#include"
            ,"In order to properly use a variable","The variable must have a valid type","The variable name can not be a keyword","The variable name must begin with a letter"
            ,"All of these","All of these"
            ,"Which function is used to print something on console","printf()","scanf()","getch()","clrscr()","printf()"
            ,"Which mathematical operators are in the correct order","Addition,Division,Modulus","Division,Multiplication,Modulus"
            ,"Modulus,Division,Multiplication","Modulus,Addition,Division","Division,Multiplication,Modulus"
            ,"In which standard library file is the function printf() located","stdlib.h","stdout.h","conio.h","stdio.h","stdio.h"
            ,"A function prototypes are useful","Because they tell the compiler that a function is declared later","Because they make the program more readable"
            ,"The programmer to see a quick list of functions in the program along with the arguments for each function","All of these","All of these"
            ,"Which function is used to read the input from console","scanf()","clrscr()","printf()","getch()","scanf()"
            ,"Which of the following is the correct operator to compare two variables",":=","==","equal","=","=="
            ,"Which of the following is not a correct variable type","real","int","float","double","real"
            ,"What punctuation is used to signal the beginning and end of code blocks","{ }","-> and <-","BEGIN and END","( and )","{ }"
            ,"Which of the following is a correct comment","*/Comment*/","**Comment**","/*Comment*/","/Comment/","/*Comment*/"
            ,"What is the only function all C programs must contain","start()","main()","system()","program()","main()"
            ,"What is the correct value to return to the operating system upon the successful completion of a program","-1","1"
            ,"Programs do not return a value","0","0"
            ,"What punctuation ends most of lines of C code",";",",",":","'",";"
            ,"Which of the following is two-dimensional array","int array = new array[20][20]","int array[20],[20]"
            ,"int array[20][20]","int aray[20][20]","int aray[20][20]")
        var db = DatabaseHelper(this)
        arQueNo = arrayListOf(0,5,10,15,20,25,30,40,50)
        var adp = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item, arQueNo)
        spQueNo.adapter = adp
        spQueNo.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
               pos = position
            }
        }

        btnStartQuiz.setOnClickListener {
            if(pos == 0) {
                Toast.makeText(this,"Select Number of Question First",Toast.LENGTH_SHORT).show()
//                Toast.makeText(this, arQue.size.toString(),Toast.LENGTH_SHORT).show()
            }
            else {
                res = db.addQue(arQue)
                if(res > 0) {
                    Toast.makeText(this,"Questions Added Successfully",Toast.LENGTH_SHORT).show()
                }
                else {
                    Toast.makeText(this,"Error in Added!!!",Toast.LENGTH_SHORT).show()
                }
                var noQue = arQueNo[pos]
                var intent1 = Intent(this,StartQuizActivity::class.java)
                intent1.putExtra("no",noQue)
                startActivity(intent1)
                finish()
            }
        }

        /*btnView.setOnClickListener {
            var intent1 = Intent(this,ViewAllQueActivity::class.java)
            startActivity(intent1)
        }*/
    }
}
