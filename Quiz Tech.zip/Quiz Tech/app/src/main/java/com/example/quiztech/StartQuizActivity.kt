package com.example.quiztech

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_start_quiz.*
import java.util.*

class StartQuizActivity : AppCompatActivity() {

    var i:Int = 0
    var score:Int = 0
    var t:Long = 0
    var time:Long = 21000
    lateinit var countDownTimer: CountDownTimer
    lateinit var ans:String
    lateinit var rdId:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_quiz)

        var no = intent.getIntExtra("no",0)
        var db = DatabaseHelper(this)
        var arQue = db.fetchQue()
        Collections.shuffle(arQue)
        var arOp = db.fetchOption(arQue[i])
        Collections.shuffle(arOp)

        txtQno.text = "Question : ${i+1}/$no"
        txtQuestion.text = arQue[i]
        rdA.text = arOp[0]
        rdB.text = arOp[1]
        rdC.text = arOp[2]
        rdD.text = arOp[3]
        ans = db.fetchAns(arQue[i])

        rdOpGroup.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.rdA) {
                rdId = rdA.text.toString()
            }
            if(checkedId == R.id.rdB) {
                rdId = rdB.text.toString()
            }
            if(checkedId == R.id.rdC) {
                rdId = rdC.text.toString()
            }
            if(checkedId == R.id.rdD) {
                rdId = rdD.text.toString()
            }
        }

        countDownTimer = object : CountDownTimer(time,1000) {
            override fun onFinish() {
                txtTimer.text = "Time : 00:0" + t
                if(rdOpGroup.checkedRadioButtonId == -1) {
                    btnConfirmNext.text = "Next"
                    changedRadioGroupcolor()
                }
                else {
                    if(rdOpGroup.checkedRadioButtonId >= 0)
                        btnConfirmNext.performClick()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                t = millisUntilFinished / 1000
                if(t < 10) {
                    txtTimer.text = "Time : 00:0" + t
                    txtTimer.setTextColor(Color.RED)
                }
                else {
                    txtTimer.text = "Time : 00:" + t
                    txtTimer.setTextColor(Color.BLACK)
                }
            }
        }.start()

        btnConfirmNext.setOnClickListener {
            if(btnConfirmNext.text == "Confirm")
            {
                if(rdOpGroup.checkedRadioButtonId == -1) {
                    Toast.makeText(this,"Select Answer first...", Toast.LENGTH_SHORT).show()
                }
                else {
                    if(rdId == ans) {
                        score++
                        txtScore.text = "Score : " + score
                    }
                    else {
                        txtScore.text = "Score : " + score
                    }
                    if(i < (no-1)) {
                        btnConfirmNext.text = "Next"
                    }
                    else {
                        btnConfirmNext.text = "Finish"
                    }
                    changedRadioGroupcolor()
                    countDownTimer.cancel()
                }
            }
            else if(btnConfirmNext.text == "Next" || btnConfirmNext.text == "Finish") {
                i++
                if(btnConfirmNext.text == "Finish") {
                    btnConfirmNext.text == "Confirm"
//                    var res = db.delQue()
//                    if(res > 0) {
//                        Toast.makeText(this,"Questions Deleted Successfully $res",Toast.LENGTH_SHORT).show()
//                    }
//                    else {
//                        Toast.makeText(this,"Error in Delete!! $res",Toast.LENGTH_SHORT).show()
//                    }
                    var intent1 = Intent(this,ResultActivity::class.java)
                    intent1.putExtra("score",score)
                    intent1.putExtra("no",no)
                    startActivity(intent1)
                    finish()
                }
                if(i < no)
                {
//                    Toast.makeText(this,"$i",Toast.LENGTH_LONG).show()
                    btnConfirmNext.text = "Confirm"
                    txtQno.text = "Question : ${i+1}/$no"
                    txtQuestion.text = arQue[i]
                    var arOp = db.fetchOption(arQue[i])
                    Collections.shuffle(arOp)
                    rdA.text = arOp[0]
                    rdB.text = arOp[1]
                    rdC.text = arOp[2]
                    rdD.text = arOp[3]
                    ans = db.fetchAns(arQue[i])
                    rdOpGroup.clearCheck()
                    defaultRadioGroupColor()
                    countDownTimer.start()
                }
            }
        }
    }
    fun changedRadioGroupcolor()
    {
        if(rdA.text == ans)
            rdA.setTextColor(Color.GREEN)
        else
            rdA.setTextColor(Color.RED)
        if(rdB.text == ans)
            rdB.setTextColor(Color.GREEN)
        else
            rdB.setTextColor(Color.RED)
        if(rdC.text == ans)
            rdC.setTextColor(Color.GREEN)
        else
            rdC.setTextColor(Color.RED)
        if(rdD.text == ans)
            rdD.setTextColor(Color.GREEN)
        else
            rdD.setTextColor(Color.RED)
    }
    fun defaultRadioGroupColor()
    {
        rdA.setTextColor(Color.BLACK)
        rdB.setTextColor(Color.BLACK)
        rdC.setTextColor(Color.BLACK)
        rdD.setTextColor(Color.BLACK)
    }
    override fun onDestroy() {
        super.onDestroy()
        var db = DatabaseHelper(this)
        var res = db.delQue()
        if(res > 0) {
            Toast.makeText(this,"Questions Deleted Successfully",Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this,"Error in Deleted!!!",Toast.LENGTH_SHORT).show()
        }
    }
}
