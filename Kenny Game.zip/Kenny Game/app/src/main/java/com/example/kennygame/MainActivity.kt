package com.example.kennygame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    var point = 0
    var imgArray = ArrayList<ImageView>()
    var handler = Handler()
    var runnable = Runnable {  }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgArray = arrayListOf(imageView1, imageView2, imageView3, imageView4, imageView5, imageView6, imageView7, imageView8
            , imageView9, imageView10, imageView11, imageView12, imageView13, imageView14, imageView15, imageView16)
        point = 0
        hideImg()

        btnStart.setOnClickListener {
            btnStart.visibility = View.INVISIBLE
            randomImg()
            object : CountDownTimer(30000, 1000) {
                override fun onFinish() {
                    handler.removeCallbacks(runnable)
                    timerText.text = "Time's Off"
                    val int1 = Intent(this@MainActivity,DisplayScoreActivity::class.java)
                    int1.putExtra("score",point)
                    startActivity(int1)
                    btnStart.visibility = View.VISIBLE

                }

                override fun onTick(millisUntilFinished: Long) {
                    timerText.text = "Timer : " + millisUntilFinished / 1000
                }
            }.start()
        }
    }

    fun randomImg(){
        runnable = object: Runnable {
            override fun run() {
                hideImg()
                val random = Random()
                val ind = random.nextInt(15-0)
                imgArray[ind].visibility = View.VISIBLE
                handler.postDelayed(runnable,500)
            }
        }
        handler.post(runnable)
    }

    fun hideImg() {
        for (img in imgArray) {
            img.visibility = View.INVISIBLE
        }
    }

    fun increaseScore(view: View) {
        point += 1
        scoreText.text = "Score : " + point
    }
}

